This is a modified version of the Adafruit LCD I2C Backpack (ID #292) driver for LCD displays. File names have been modified to avoid confilct with the Arduino versions of the code. I used MPIDE 20120903 to compile the code.

Doug - WB6AJX

